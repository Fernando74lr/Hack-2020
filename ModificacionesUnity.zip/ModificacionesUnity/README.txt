Las modificiones realizadas son las siguientes:
Assets, añadimos RestClient

Modificamos "PlayerDataManager.cs" y "UserDataManager.cs"

